import React from 'react'

const Loader = () => {
    return (
        <img style={{width:"70px"}} src={require('../../../assets/loader.gif')} alt="spinner"/>
    )
}
export default Loader;